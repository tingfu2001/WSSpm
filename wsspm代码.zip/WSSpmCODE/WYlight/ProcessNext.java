package ca.pfv.spmf.algorithms.frequentpatterns.apriori_close;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.math.BigDecimal;
import java.nio.channels.FileLock;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.util.List;
import ca.pfv.spmf.tools.MemoryLogger;

public class ProcessNext {
    static HashMap<Integer, Float> LMW;
    static Float tsmw;
    static Float MW;
    public static HashMap<String,Float> itemweight;
    static String prefix;
    public static HashMap<Integer,String> DB;
    static int xprefix;
    public static Integer totaln;
    public static int n1;
    public static int num;
    static List<ArrayList<Integer>> Cj;
    static ArrayList<BigDecimal> pjmin;
    static  HashMap<BigDecimal,Float> FWER;//the key is significant level while the value is correlated FWER value
    static BigDecimal siglevel;
    static float threshold;
    static int minfreq;
    static HashMap<Integer,Float> preWeight;
    static HashMap<Integer,Integer> preWeightFreq;
    public static HashMap<BigDecimal, ArrayList<String>> record;
    /*---------------used for depth-first------------------*/

    public static Stack<String> depstack;//this one store prefix
    public static Stack<HashMap<Integer,Integer>> depstack2;// this one store the projectedDB of related prefix
    public static int numpattern;

    public static void main() throws IOException {
        //start the depth-first mining from the root
        numpattern = 0;
        depstack = new Stack<String>();
        depstack2 = new Stack<HashMap<Integer,Integer>>();
        FWER = new HashMap<BigDecimal,Float>();
        record = new HashMap<BigDecimal, ArrayList<String>>();
        // here I put all the item in the original DB into the stack
        for (String item : itemweight.keySet()) {
            depstack.push(item);
            prefix = item;
            //mine the projectedDB of the item
            /*here the function of projectedDB and calxp will be rewritten, the new projectedDB will
             * be a pointer, that is, key is seqID and value is the first position of the projected seq*/
            HashMap<Integer,Integer> newprojectedDB = calprojDB(null, prefix);
            depstack2.push(newprojectedDB);
        }
        while (!depstack.isEmpty()) {//here is the depth-first loop
            MemoryLogger.getInstance().checkMemory();
            //first I will calculate the xp of the prefix, and the projected database of it
            prefix = depstack.pop();
            numpattern++;
            HashMap<Integer, Integer> projectedDB = depstack2.pop();
            //here calxp
            xprefix = projectedDB.size();

            /*first we compute the p-value for the u in the range*/
            int asmin = 0;
            int asmax = n1;
            if ((xprefix - totaln + n1) > 0) {
                asmin = xprefix - totaln + n1;
            }
            if (xprefix < n1) {
                asmax = xprefix;
            }
            //line 1 Hashmap astop is store the as and related p-value.
            HashMap<Integer, BigDecimal> astop = new HashMap<Integer, BigDecimal>();
            for (int u = asmin; u <= asmax; u++) {
                BigDecimal psu = calpvalue(u, asmin, asmax,xprefix);
                astop.put(u, psu);
            }
            // line 2 to line 5
            MemoryLogger.getInstance().checkMemory();
            for (int j = 0; j <num; j++) {
                ArrayList<Integer> Cofj = Cj.get(j);
                /* In the list Cifj the 1-th to n1-th in the list is labeled as c1 the rest (n1+1) to
                 * n-th is labeled as c0*/
                //following part we calculate aj
                int aj = calas(Cofj,projectedDB);
                //now we calculate p(aj)
                BigDecimal paj = calpvalue(aj, asmin, asmax,xprefix);
                if (paj.compareTo(pjmin.get(j))!=1 ) {
                    pjmin.set(j, paj);
                    ArrayList<String> temp = record.get(paj);
                    if(temp == null){
                        ArrayList<String> temp2 = new ArrayList<String>();
                        temp2.add(prefix);
                        record.put(paj,temp2);
                    }else{
                        temp.add(prefix);
                        record.replace(paj,temp);
                    }
                }
            }
            MemoryLogger.getInstance().checkMemory();
            //here, the pmin is globally updated
            //next is the calculation of FWER(delata) line 6
            Float temp = calFWER();
            FWER.put(siglevel, temp);
            //line 7 to line 10
            while (FWER.get(siglevel) > threshold) {
                minfreq++;
                siglevel = lowerp(minfreq);
                Float temp2 = calFWER();
                FWER.put(siglevel, temp2);
            }
            MemoryLogger.getInstance().checkMemory();
            //line 11 to line 17
            ArrayList<String> iteminproDB = finditem(projectedDB);
            for (int i = 0; i < iteminproDB.size(); i++) {//for potential pattern extend (children)
                String item = iteminproDB.get(i);
                String candidate = prefix+item;

                HashMap<Integer, Integer> newprojectedDB = calprojDB(projectedDB,item);
                int xp = newprojectedDB.size();
                if (xp == 0) {
                    continue;
                }

                MemoryLogger.getInstance().checkMemory();
                if (xp >= minfreq) {// here is the weighted upper bound part
                    depstack.push(candidate);
                    depstack2.push(newprojectedDB);
                }
            }

        }
        Main.pjmin = pjmin;//return the global value set p-min
        Main.record = record;
        Main.numpattern = numpattern;
        Main.minfreq = minfreq;
        MemoryLogger.getInstance().checkMemory();
    }



    public static ArrayList<String> finditem(HashMap<Integer,Integer> oldprojDB){
        ArrayList<String> iteminproDB =  new ArrayList<String>();
        for(Integer id : oldprojDB.keySet()) {
            int position = oldprojDB.get(id);//the pointer of the projected seq
            String seq = DB.get(id);
            for(int n = position+1; n<seq.length();n++){
                String item = String.valueOf(seq.charAt(n));
                if(iteminproDB.contains(item)==false){
                    iteminproDB.add(item);
                }
            }
        }
        MemoryLogger.getInstance().checkMemory();
        return iteminproDB;
    }


    public static HashMap<Integer,Integer> calprojDB(HashMap<Integer,Integer> oldprojDB, String newitem){
        // the key is seqID and the value is the position of the prefix
        HashMap<Integer,Integer> newprojDB = new HashMap<Integer,Integer>();
        if(oldprojDB == null){
            //that is, the prefix is a single item
            for(Integer id: DB.keySet()) {
                String seq = DB.get(id);
                int have =0;
                int position = 0;
                for(int j = 0; j<seq.length();j++) {
                    String item = String.valueOf(seq.charAt(j));
                    if(newitem.equals(item)) {//Note that this contains function is only fit of length-1 checking
                        position = j;
                        have = 1;
                        break;
                    }
                }
                if(have==1){
                    newprojDB.put(id,position);
                }
            }
        }else{
            //following part is similar with the function calxp
            for(Integer id : oldprojDB.keySet()) {
                int position = oldprojDB.get(id);//the pointer of the projected seq
                String seq = DB.get(id);
                int newposition = 0;
                int have =0;
                //for each projected seq
                for(int n = position+1; n<seq.length();n++){
                    String item = String.valueOf(seq.charAt(n));
                    if(newitem.equals(item)) {//Note that this contained function is only fit of length-1 checking
                        newposition = n;
                        have = 1;
                        break;
                    }
                }
                if(have==1){
                    newprojDB.put(id,newposition);
                }
            }
        }
        MemoryLogger.getInstance().checkMemory();
        return newprojDB;
    }


    public static void calpreFW(String item, HashMap<Integer,Integer> pDB){
        preWeight = new HashMap<Integer,Float>();//key is the +x, value is the sum of related LMW
        preWeightFreq = new HashMap<Integer,Integer>();//key is +x，value is the num of its seq
        for(Integer id: pDB.keySet()) {
            String seq = DB.get(id);
            int x = seq.length();
            if(preWeight.get(x)==null){
                preWeight.put(x,LMW.get(id));
                preWeightFreq.put(x,1);
            }else{
                Float tempLMW = preWeight.get(x)+ LMW.get(id);
                Integer tempnum = preWeightFreq.get(x)+1;
                preWeight.replace(x,tempLMW);
                preWeightFreq.replace(x,tempnum);
            }
        }
        MemoryLogger.getInstance().checkMemory();
    }


    public static Integer upperbound(String item, Float theta,Integer xp,HashMap<Integer,Integer> pDB){
        Integer result = 0;
        //now following the new weighted upper-bound
        Float MaxPWS = 0.0f;
        Float leftSum = 0.0f;
        Integer theN = 0;
        calpreFW(item,pDB);
        for(Integer i:preWeight.keySet()){
            leftSum = leftSum + preWeight.get(i);
            theN = theN + preWeightFreq.get(i);
            Integer p = prefix.length();
            Float PWS = (calwv(prefix)*theN*p+i*leftSum)/(p+i);
            if(PWS>MaxPWS){
                MaxPWS = PWS;
            }
        }
        MemoryLogger.getInstance().checkMemory();
        MaxPWS = MaxPWS/tsmw;
        if(MaxPWS<theta){
            result=0;
        }else{
            result=1;
        }
        MemoryLogger.getInstance().checkMemory();
        return result;
    }


    private static Integer calas(ArrayList<Integer> Cofj,HashMap<Integer,Integer> pDB){
        int as = 0;
        /* In the list Cifj the 1-th to n1-th in the list is labeled as c1 the rest (n1+1) to
         * n-th is labeled as c0*/
        for(Integer id : pDB.keySet()){
            if(Cofj.subList(0,n1-1).contains(id)) {
                as++;
            }
        }
        return as;
    }

    public static Integer WSCbound(Float theta, Integer xp){
        Integer result = 0;
        if(((xp*MW)/tsmw)>=theta){
            result = 1;
        }
        return result;
    }



    public static Float calwv(String s) {
        Float totalw = 0f;
        for(int i = 0; i<s.length();i++) {
            String item = String.valueOf(s.charAt(i));
            totalw = totalw + itemweight.get(item);
        }
        totalw = totalw/((float)s.length());
        return totalw;
    }



    public static Float calFWER(){
        Float temp = 0.0f;
        for(int j=1;j<=num;j++){
            if(pjmin.get(j-1).compareTo(siglevel)!=1){
                temp++;
            }
        }
        MemoryLogger.getInstance().checkMemory();
        return temp = temp/num;
    }




    public static BigDecimal lowerp(Integer theminfreq){
        BigDecimal thesiglevel = BigDecimal.valueOf(-1.0f);//initialize
        if(theminfreq>n1 && theminfreq<=totaln){//the case of 0<=x_p<=n1
            thesiglevel = BigDecimal.valueOf(1).divide(combination(totaln,n1),30,BigDecimal.ROUND_HALF_UP);
            return thesiglevel;
        } else if (theminfreq>=0 && theminfreq<=n1) {//the case of n1<x_p<=n
            int apmin = 0;
            int apmax = n1;
            if((theminfreq-totaln+n1)>0){
                apmin=(theminfreq-totaln+n1);
            }
            if(theminfreq<n1){
                apmax=theminfreq;
            }
            MemoryLogger.getInstance().checkMemory();
            //here the
            BigDecimal tempmax = calpvalue(apmax,apmin, apmax,theminfreq);
            BigDecimal tempmin = calpvalue(apmin,apmin, apmax,theminfreq);
            if(tempmin.compareTo(tempmax)==1){
                thesiglevel=tempmax;
            }else{
                thesiglevel=tempmin;
            }
            return thesiglevel;
        }
        MemoryLogger.getInstance().checkMemory();
        return thesiglevel;
    }





    private static BigDecimal calpvalue(int u, int asmin, int asmax,int xp){
        BigDecimal psu = BigDecimal.valueOf(0.0f);
        BigDecimal Pu = combination(n1, u).multiply(combination((totaln - n1), (xp - u))).divide(combination(totaln, u), 30,BigDecimal.ROUND_HALF_UP);
        for (int k = asmin; k <= asmax; k++) {
            BigDecimal temp = combination(n1, k).multiply(combination((totaln - n1), (xp - k))).divide(combination(totaln, k), 30,BigDecimal.ROUND_HALF_UP);
            if(temp.compareTo(Pu)!=1){
                psu=psu.add(temp);
            }
        }
        MemoryLogger.getInstance().checkMemory();
        return psu;
    }


    private static BigDecimal factorial(int n) {
        BigDecimal sum = BigDecimal.valueOf(1.0f);
        while (n > 0) {
            BigDecimal temp = BigDecimal.valueOf(n);
            sum = sum.multiply(temp);
            n--;
        }
        return sum;
    }

    private static BigDecimal combination(int n, int m) {
        MemoryLogger.getInstance().checkMemory();
        return factorial(n).divide (factorial(n - m).multiply(factorial(m)),30,BigDecimal.ROUND_HALF_UP);
    }



}